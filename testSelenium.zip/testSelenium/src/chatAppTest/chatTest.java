package chatAppTest;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.junit.Ignore;
import org.junit.Test;
import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class chatTest {

  public static WebDriver driver;

  static String channelName, userName1, chatText1, userName2, chatText2;

  @Ignore
  public void waitForText(By locator, String value) {
    WebDriverWait wait = new WebDriverWait(driver, 10);
    wait.until(ExpectedConditions.attributeContains(locator, "innerText", value));
  }

  @Ignore
  public void waitForElement(By locator) {
    WebDriverWait wait = new WebDriverWait(driver, 10);
    wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
  }

  @Ignore
  public void waitForInvisibilityOfElement(By locator) {
    WebDriverWait wait = new WebDriverWait(driver, 10);
    wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
  }

  @BeforeClass
  public static void suiteSetup() throws IOException {
    String currentDir = System.getProperty("user.dir");
    System.out.println("Current dir using System:" + currentDir);
    FileReader fr = new FileReader("./src/resources/TestData.txt");
    BufferedReader br = new BufferedReader(fr);

    channelName = br.readLine();
    userName1 = br.readLine();
    chatText1 = br.readLine();
    userName2 = br.readLine();
    chatText2 = br.readLine();

    br.close();
    fr.close();
    System.setProperty("webdriver.chrome.driver", "./src/resources/chromedriver.exe");
    ChromeOptions options = new ChromeOptions();
    options.addArguments("--start-maximized");
    driver = new ChromeDriver(options);
    }

  @Test
  public void test_A_openHomepage() {
    String baseUrl = "https://tlk.io";
    String expectedTitle = "tlk.io";
    driver.get(baseUrl);
    assertEquals("Title should be tlk.io", expectedTitle, driver.getTitle());
  }

  @Test
  public void test_B_joinChannel() {
    WebElement channelNameInput = driver.findElement(By.id("chat_permalink"));
    WebElement joinButton = driver.findElement(By.id("join_button"));
    channelNameInput.sendKeys(channelName);
    joinButton.click();

    waitForElement(By.id("chat"));

    String expectedTitle = "tlk.io / " + channelName;
    String actualTitle = driver.getTitle();
    assertEquals("Title should be tlk.io / " + channelName, expectedTitle, actualTitle);
  }

  @Test
  public void test_C_loginUser1() {
    waitForElement(By.id("participant_nickname"));

    WebElement userNameInput = driver.findElement(By.id("participant_nickname"));

    userNameInput.sendKeys(userName1);
    userNameInput.sendKeys(Keys.RETURN);
    waitForElement(By.id("online-participants"));

    List<WebElement> updatedParticipants = driver.findElement(By.id("online-participants")).findElements(By.tagName("li"));
    assertTrue(updatedParticipants.size() > 0);
    assertEquals("The login user should reflect", userName1, updatedParticipants.get(updatedParticipants.size() - 1).getText());
  }

  @Test
  public void test_D_sendChatMessage1() {
    WebElement message = driver.findElement(By.id("message_body"));
    WebElement allMessage = driver.findElement(By.id("live"));
    List<WebElement> messageCount = driver.findElement(By.id("live")).findElements(By.tagName("dl"));

    message.sendKeys(chatText1);
    message.sendKeys(Keys.RETURN);

    waitForElement(By.id("live"));
    waitForElement(By.xpath("(//*[@id='live']/dl)[" + (messageCount.size() + 1) + "]"));

    List<WebElement> updatedMessageUserName = driver.findElement(By.id("live")).findElements(By.className("post-name"));
    assertTrue(allMessage.getText().contains(chatText1));
    assertTrue(updatedMessageUserName.size() > 0);
    assertEquals("Chat message should be sent", userName1, updatedMessageUserName.get(updatedMessageUserName.size() - 1).getText());
  }

  @Test
  public void test_E_logoutUser1() {

    WebElement userButton = driver.findElement(By.id("user-button"));

    userButton.click();
    waitForElement(By.id("sign-out"));

    WebElement signoutButton = driver.findElement(By.id("sign-out"));

    signoutButton.click();
    waitForInvisibilityOfElement(By.id("user-settings"));

    userButton.click();
    assertFalse("Logout button should disappear", signoutButton.isDisplayed());
  }

  @Test
  public void test_F_loginUser2() {
    waitForElement(By.id("participant_nickname"));

    WebElement userNameInput = driver.findElement(By.id("participant_nickname"));
    userNameInput.sendKeys(userName2);
    List<WebElement> participantsCount = driver.findElement(By.id("online-participants")).findElements(By.tagName("li"));

    userNameInput.sendKeys(Keys.RETURN);
    waitForElement(By.id("online-participants"));
    waitForElement(By.xpath("(//*[@id='online-participants']/li)[" + (participantsCount.size() + 1) + "]"));

    List<WebElement> updatedParticipants = driver.findElement(By.id("online-participants")).findElements(By.tagName("li"));
    assertTrue(updatedParticipants.size() > 0);
    assertEquals("The login user should reflect", userName2, updatedParticipants.get(updatedParticipants.size() - 1).getText());
  }

  @Test
  public void test_G_sendChatMessage2() {
    WebElement message = driver.findElement(By.id("message_body"));
    WebElement allMessage = driver.findElement(By.id("live"));
    List<WebElement> messageCount = driver.findElement(By.id("live")).findElements(By.tagName("dl"));

    message.sendKeys(chatText2);
    message.sendKeys(Keys.RETURN);

    waitForElement(By.id("live"));
    waitForElement(By.xpath("(//*[@id='live']/dl)[" + (messageCount.size() + 1) + "]"));

    List<WebElement> updatedMessageUserName = driver.findElement(By.id("live")).findElements(By.className("post-name"));
    assertTrue(allMessage.getText().contains(chatText2));
    assertTrue(updatedMessageUserName.size() > 0);
    assertEquals("Chat message should be sent", userName2, updatedMessageUserName.get(updatedMessageUserName.size() - 1).getText());
  }

  @Test
  public void test_H_logoutUser2() {

    WebElement userButton = driver.findElement(By.id("user-button"));

    userButton.click();
    waitForElement(By.id("sign-out"));

    WebElement signoutButton = driver.findElement(By.id("sign-out"));

    signoutButton.click();
    waitForInvisibilityOfElement(By.id("user-settings"));

    userButton.click();
    assertFalse("Logout button should disappear", signoutButton.isDisplayed());
  }
  
  @Test
  public void test_I_logoutChannel() {

    WebElement logoutChannel = driver.findElement(By.className("header-avatar"));

    logoutChannel.click();
    waitForElement(By.id("chat_permalink"));

    String expectedTitle = "tlk.io";
    assertEquals("Should navigate to home page", expectedTitle, driver.getTitle());
  }
  
  @AfterClass
  public static void testEnd() {
    driver.close();
  }

}
